#include<stdio.h>

main(){

    int num;

    printf("\n Digite um numero: ");
    scanf("%d",&num);


    if(num %2 ==0){

        printf("\n O numero e par");
    }else{
        printf("\n");
    }
}